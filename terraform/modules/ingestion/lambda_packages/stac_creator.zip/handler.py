"""
STAC Creator Lambda Function
Reads Zarr metadata and generates STAC item JSON with bounding box

Requirements: 4.1, 4.2, 4.3, 4.5, 4.6, 4.7
"""
import json
import os
import boto3
from datetime import datetime, timezone
from pathlib import Path

s3_client = boto3.client('s3')


def read_metadata_from_s3(bucket, key, client=None):
    """
    Read metadata file from S3
    
    Args:
        bucket: S3 bucket name
        key: S3 key for metadata file
        client: Optional S3 client (for testing)
        
    Returns:
        dict: Metadata containing bbox and other information
        
    Raises:
        ValueError: If metadata file cannot be read
    """
    if client is None:
        client = s3_client
    
    try:
        response = client.get_object(Bucket=bucket, Key=key)
        metadata = json.loads(response['Body'].read().decode('utf-8'))
        return metadata
    except Exception as e:
        raise ValueError(f"Failed to read metadata from s3://{bucket}/{key}: {e}")


def create_geometry_from_bbox(bbox):
    """
    Create GeoJSON polygon geometry from bounding box
    
    Args:
        bbox: List of [west, south, east, north]
        
    Returns:
        dict: GeoJSON Polygon geometry
    """
    west, south, east, north = bbox
    
    return {
        "type": "Polygon",
        "coordinates": [[
            [west, south],   # SW corner
            [east, south],   # SE corner
            [east, north],   # NE corner
            [west, north],   # NW corner
            [west, south]    # Close the polygon
        ]]
    }


def derive_stac_key(zarr_key):
    """
    Derive STAC key from zarr key
    
    Args:
        zarr_key: Zarr file S3 key (e.g., "zarr/file.zarr")
        
    Returns:
        str: STAC key in format "stac/{basename}.json"
    """
    basename = Path(zarr_key).stem
    return f"stac/{basename}.json"


def lambda_handler(event, context):
    """
    Create STAC item from Zarr metadata
    
    Args:
        event: Contains input_key, zarr_bucket, cog_bucket, stac_bucket
        context: Lambda context
        
    Returns:
        dict: Response with STAC item S3 key
    """
    try:
        # Extract inputs from Step Functions
        input_key = event['input_key']
        zarr_bucket = event['zarr_bucket']
        cog_bucket = event['cog_bucket']
        stac_bucket = event.get('stac_bucket', zarr_bucket)
        
        # Compute zarr_key and cog_key from input_key
        # Transform ingestion/file.nc -> zarr/file.zarr
        filename = input_key.split('/')[-1]  # Get last part
        zarr_filename = filename.replace('.nc', '.zarr')
        zarr_key = f'zarr/{zarr_filename}'
        
        # Transform ingestion/file.nc -> cog/file.tif
        cog_filename = filename.replace('.nc', '.tif')
        cog_key = f'cog/{cog_filename}'
        
        print(f"Input: {input_key}")
        print(f"Creating STAC item for zarr: s3://{zarr_bucket}/{zarr_key}")
        print(f"COG location: s3://{cog_bucket}/{cog_key}")
        
        # Read metadata file from S3
        # Metadata file is created by zarr_converter and contains bbox
        metadata_key = zarr_key.replace('.zarr', '_metadata.json')
        print(f"Reading metadata from: s3://{zarr_bucket}/{metadata_key}")
        
        metadata = read_metadata_from_s3(zarr_bucket, metadata_key)
        bbox = metadata['bbox']
        
        print(f"Extracted bounding box: {bbox}")
        
        # Extract basename for STAC ID
        basename = Path(zarr_key).stem
        
        # Create STAC item with bounding box
        stac_item = {
            "type": "Feature",
            "stac_version": "1.0.0",
            "id": basename,
            "bbox": bbox,
            "geometry": create_geometry_from_bbox(bbox),
            "properties": {
                "datetime": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                "created": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                "updated": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
            },
            "assets": {
                "zarr": {
                    "href": f"s3://{zarr_bucket}/{zarr_key}",
                    "type": "application/vnd+zarr",
                    "roles": ["data"]
                },
                "cog": {
                    "href": f"s3://{cog_bucket}/{cog_key}",
                    "type": "image/tiff; application=geotiff; profile=cloud-optimized",
                    "roles": ["visual"]
                }
            },
            "links": []
        }
        
        # Write STAC item to S3
        stac_bucket = os.environ.get('STAC_BUCKET', zarr_bucket)
        stac_key = derive_stac_key(zarr_key)
        
        s3_client.put_object(
            Bucket=stac_bucket,
            Key=stac_key,
            Body=json.dumps(stac_item, indent=2),
            ContentType='application/json'
        )
        
        print(f"Created STAC item: s3://{stac_bucket}/{stac_key}")
        
        return {
            'statusCode': 200,
            'stac_key': stac_key,
            'stac_id': stac_item['id'],
            'stac_bucket': stac_bucket
        }
        
    except Exception as e:
        print(f"Error creating STAC item: {str(e)}")
        import traceback
        traceback.print_exc()
        raise
